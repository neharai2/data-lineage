const mongoose=require("mongoose");
const schema=mongoose.Schema(
    {
        SubApplicationName:"String",
        Portfolioid :{type:mongoose.Schema.Types.ObjectId,ref:'portfolio',required:true} 
    },
    {timestamps: true}
)



const SubApplicationMaster=mongoose.model('SubApplicationName',schema);
module.exports=SubApplicationMaster;