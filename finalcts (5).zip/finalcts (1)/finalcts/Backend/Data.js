const router=require("express").Router();
const express=require("express")
const app=express();
app.use(express.json())
router.use(express.json());
//import Model
const PortfolioMaster= require ("./PorfolioData");
const SubApplicationMaster=require("./SubApplicationData");
const AppAcroMaster=require("./AppAcroData");
const FlowchartMaster=require("./FlowchartIntegrationModel");

//Default Route
//GET ALL portfolio MASTER DATA
router.get("/getporfoliodata",async(req,res)=>{
    try{
const Getporfoliodata=await PortfolioMaster.find().select('PorfolioName');
res.json(Getporfoliodata);
    }
    catch(error){
res.status(500).send(error);
    }
})

//POST All portfolio Master Data
router.post("/postporfoliodata",async(req,res)=>{
    const{PorfolioName}=req.body;
    try {
       const postporfoliodata=await PortfolioMaster.create({PorfolioName});
       res.send(postporfoliodata);

    } catch (error) {
        res.status(500).send(error);
    }
})

//Post Subapplication data
router.post("/postSubApplicationData",async(req,res,next)=>{
 const{SubApplicationName,Portfolioid}=req.body;
 try{
      const postSubApplicationData=await SubApplicationMaster.create({SubApplicationName,Portfolioid})
      res.send(postSubApplicationData);
 }
catch(error){
    res.status(500).send(error);
}

})
//get all subapplicationdata.js
router.get("/getsubapplication/:Portfolioid",async(req,res)=>{
    const {Portfolioid}=req.params;
    //console.log(Portfolioid);
    try{
const getsubapplication=await SubApplicationMaster.find({Portfolioid}).select('Portfolioid SubApplicationName');
res.json(getsubapplication);
    }
    catch(error){
res.status(500).send(error);
    }
})

//Post AppAcronym Data
router.post("/PostAppAcronym",async(req,res,next)=>{
    const{AppAcronymName,SubApplicationId,Portfolioid}=req.body;
    try{
         const PostAppAcronym=await AppAcroMaster.create({AppAcronymName,SubApplicationId,Portfolioid})
         res.send(PostAppAcronym);
    }
   catch(error){
       res.status(500).send(error);
   }
   
   })
   //get all appacronymdata.js
router.get("/getappacronym/:SubApplicationId",async(req,res)=>{
    const {SubApplicationId}=req.params;
    //console.log(Portfolioid);
    try{
const getappcronym=await AppAcroMaster.find({SubApplicationId})
.select('AppAcronymName SubApplicationId Portfolioid');
res.json(getappcronym);
    }
    catch(error){
res.status(500).send(error);
    }
})

//post flowchart data
router.post('/flowchartpost',async(req,res)=>{
    console.log("POST REQUEST");
const{Application1,Application2,Direction,Notes,AppAcroId}=req.body;
try{
const newflowchartpost=await FlowchartMaster.create({Application1,Application2,Direction,
    Notes,AppAcroId});
res.send(newflowchartpost);
console.log(newflowchartpost);
}
catch(error){ 
res.status(500).send(error);
console.log(error);
}
});

//get flowchart by specific id 
router.get("/getflowchart/:AppAcroId",async(req,res)=>{
    const { AppAcroId}=req.params;
 console.log(AppAcroId);
    try{
const getflowchart=await FlowchartMaster.find({AppAcroId}).select('Application1 Application2 Notes Direction AppAcroId ');
res.json(getflowchart);
    }
    catch(error){
res.status(500).send(error);
    }
})



// -----------------------ANMOL APIS ----------------------------




router.post("/getflowchart/add",(req,res)=>// api for adding the data into the flowchart
{
    const edititem = new  FlowchartMaster(req.body)
    edititem.save();
    res.send("Item Edited")

}

)
router.get("/getflowchart",async(req,res)=>// displaying all the record
{
    const edititem = await  FlowchartMaster.find()  
    res.send(edititem)
}
)
router.patch("/getflowchart/item/edit/:id",async(req,res)=> // api for updating or editing
{
    const edititem = await FlowchartMaster.findByIdAndUpdate(req.params.id,req.body,{new:true})
    res.send(edititem)
    // edititem.save();
    // res.send("Item Updated")
}
)
router.get("/getflowchart/item/:id",async(req,res)=>// api for displaying the data by their id
{
    const edititem = await FlowchartMaster.findById(req.params.id)
    console.log(req.params.id);
    res.send(edititem)
    // edititem.save();
    // res.send("Item Updated")
}
)

router.delete("/getflowchart/item/delete/:id",async(req,res)=>// api for deleteing the data by id
{
    const deleteitem = await FlowchartMaster.findByIdAndDelete(req.params.id)
    console.log(req.params.id)
    // edititem.save();
    res.send("Item Deleted")
}
)
module.exports=router;