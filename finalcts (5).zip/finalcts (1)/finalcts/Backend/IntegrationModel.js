const mongoose=require("mongoose");
const schema=mongoose.Schema(
    {
        
        Application1:'String',
        Application2:'String',
    Direction:'String',
    Type_Of_Data_Involved:'String',
    Notes:'String',
    },
    {timestamps: true}
)
const IntegrationMaster= new mongoose.model('integration',schema);
module.exports=IntegrationMaster;