const mongoose=require("mongoose");
const schema=mongoose.Schema(
    {
      PorfolioName:"String",  
    },
    {timestamps: true}
)



const PortfolioMaster=mongoose.model('portfolio',schema);
module.exports=PortfolioMaster;