const mongoose=require("mongoose");
const schema=mongoose.Schema(
    {
        Internal_Purchased:'String',
    Portfolio:'String',
    Sub_App_Area:'String',
    App_Acronym:'String',       
    App_Name:'String',
    Notes:'String',
    },
    {timestamps: true}
)
const AppMaster=mongoose.model('appMaster',schema);
module.exports=AppMaster;