const router=require("express").Router();

const appMasterModel=require("./appMasterModel");

const integrationModel=require("./IntegrationModel");

const express=require("express")
const app=express();
const cors=require("cors");

router.use(cors());
//get routes
app.use(express.json())
router.use(express.json());
router.get("/getting",(req,res)=>{
    res.send("This is official router");
})
router.get("/getall",(req,res)=>{
    res.send("User exist");
})
//get all AppMaster Routes
router.get("/getappMaster",async(req,res)=>{
    try{
const GetallappMaster=await appMasterModel.find();
res.json(GetallappMaster);
    }
    catch(error){
        res.status(500).send(error);
    }
})
//get single AppMasterRoutes
router.get("/:id",async(req,res)=>{
    const {id}=req.params;
    try{
const getSingleAppMaster=await appMasterModel.findById(id);
res.json(getSingleAppMaster);
    }
    catch(error){
        res.status(500).send(error);
    }
})

//Post AppMaster Routes
router.post('/appMasterPost',async(req,res)=>{
    console.log("POST REQUEST");
const{Internal_Purchased,Portfolio,Sub_App_Area,App_Acronym,App_Name,Notes}=req.body;
try{
const newappMasterPost=await appMasterModel.create({Internal_Purchased,Portfolio,Sub_App_Area,App_Acronym,App_Name,Notes});
res.send(newappMasterPost);
newappMasterPost.save();
console.log(`\n${newappMasterPost}\n\n inserted !!!`)
}
catch(error){ 
res.status(500).send(error);
}
});
//update appimasterrequest Request
router.put('/:id/updateappmaster',async(req,res)=>{
    const{id}=req.params;
    console.log(req.body);
    const{Internal_Purchased,Portfolio,SubApplication_Area,SubApplication_Acronym,Application_Name,Notes}=req.body;
    try{
const UpdateAppMaster=await appMasterModel.findByIdAndUpdate(id,{Internal_Purchased,Portfolio,SubApplication_Area,SubApplication_Acronym,Application_Name,Notes})
res.send(UpdateAppMaster);
UpdateAppMaster.save();
console.log(`\n\n${UpdateAppMaster} \n Data Updated !!!`)
    }
    catch(error){
        console.log(error);
        res.status(500).send(error);
    }
})
//delete appmaster

router.delete("/:id",async(req,res)=>{
    const{id}=req.params;
    try{
        const DeleteAppMaster=await appMasterModel.findByIdAndDelete(req.params.id);
        res.json(DeleteAppMaster);
        
    }
    catch(error){
        console.log(error);
        res.status(500).send(error);
    }
})



//get Integration all routes
router.get("/k/getroutes", async(req,res)=>{ 
    try{
const GetallIntegration=await integrationModel.find();
res.json(GetallIntegration);

    }
    catch(error){
        console.log(error);
        res.status(500).send(error);
    }
})
//get single integration by id
router.get("/ai/:id/honey",async(req,res)=>{
    const {id}=req.params;
    try{
const getSingleIntegration=await integrationModel.findById(id);
res.json(getSingleIntegration);
    }
    catch(error){
        res.status(500).send(error);
    }
})


//Post Integration Routes
router.post('/integrationPost',async(req,res)=>{
    console.log("POST REQUEST");
   
    
const{Application1,Application2,Direction,Type_Of_Data_Involved,Notes}=req.body;
try{
const newintegrationPost=await integrationModel.create({Application1,Application2,Direction,Type_Of_Data_Involved,Notes});
res.send(newintegrationPost);
console.log(newintegrationPost);
}
catch(error){ 
res.status(500).send(error);
console.log(error);
}
});
//update integration Routes
router.put('/h/:id/updateIntegration',async(req,res)=>{
    const{id}=req.params;
    const{Application1,Application2,Direction,Type_Of_Data_Involved,Notes}=req.body;
    try{
const updateIntegrations=await integrationModel.findByIdAndUpdate(id,{Application1,Application2,Direction,Type_Of_Data_Involved,Notes})
res.send(updateIntegrations);
updateIntegrations.save();
    }
    catch(error){
        console.log(error);
        res.status(500).send(error);
    }
})

//delete integration routes
router.delete("/:id",async(req,res)=>{
    const{id}=req.params;
    try{
        const DeleteIntegrationMaster=await integrationModel.findByIdAndDelete(req.params.id);
        res.json(DeleteIntegrationMaster);
        
    }
    catch(error){
        console.log(error);
        res.status(500).send(error);
    }
})

module.exports=router;