const mongoose=require("mongoose");
const schema=mongoose.Schema(
    {
        AppAcronymName:"String",
        SubApplicationId:{type:mongoose.Schema.Types.ObjectId,ref:'SubApplicationName',required:true},
        Portfolioid :{type:mongoose.Schema.Types.ObjectId,ref:'portfolio',required:true} 
    },
    {timestamps: true}
)



const AppAcroMaster=mongoose.model('AppAcronymName',schema);
module.exports=AppAcroMaster;