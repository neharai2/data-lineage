const mongoose=require("mongoose");
const schema=mongoose.Schema(
    {
        
        Application1:'String',
        Application2:'String',
    Direction:'String',
    Notes:'String',
    AppAcroId :{type:mongoose.Schema.Types.ObjectId,ref:'AppAcronymName'} 
    },
    {timestamps: true}
)

const FlowchartMaster=mongoose.model('flowchart',schema);
module.exports=FlowchartMaster;