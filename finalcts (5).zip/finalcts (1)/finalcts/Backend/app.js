//import express
const express=require("express");
const cors=require("cors");
//app using express
const app=express();
app.use(cors());
//import cors

//import connection of mongodb
const db=require("./connection");



app.use(express.json());

//import Routes
const UserMasterRouter=require("./UserRouter");
const DataFlow=require("./Data");
//Midlleware
app.use("/user",UserMasterRouter);
app.use("/data",DataFlow);

app.use("/",(req,res)=>{
    res.status(404).json({message:"bad url"});
})
//app listening on port 5000h
app.listen(4200,()=>{
    console.log("running on port 4200");
})