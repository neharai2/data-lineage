import  { useState,useEffect } from "react";
import React from "react";
import "./dataf.css";
import Navbar from './Navbar';
const Dataf = () => {
const [Portfoliodata,SetPortfolioData]=useState([]);
const[SecondPortfolio,SetSecondPortfolio]=useState(" ");
const[SubApplicationdata,SetSubApplicationdata]=useState([]);
useEffect(()=>{
const getPortfolio=async()=>{
  const resPortfolio=await fetch("http://localhost:4200/data/getporfoliodata");
  const resPortfoliodata= await resPortfolio.json();
  SetPortfolioData(await resPortfoliodata);
  
}
getPortfolio();

},[])

const HandlePortfolio=(event,hii)=>{
const GetPortfolioId=event.target.value;
console.log(hii);
SetSecondPortfolio(GetPortfolioId);
}

useEffect(()=>{
  debugger
const getSubApplication=async()=>{ debugger
  const resSubApplication=  await fetch(`http://localhost:4200/data/getsubapplication/633aa142ba61ad209e9051eb`);
  const resSubApplicationdata=await resSubApplication.json();
  SetSubApplicationdata( await resSubApplicationdata)
}
getSubApplication();
},[SecondPortfolio])
console.log(SubApplicationdata);

  return (
    <>
    <div className="harshit">
    <div className="block3">
      <Navbar/>
      </div>
      
<div className="block2">
  <form>
 <div>
 <select onChange={(e)=>HandlePortfolio(e,'harry')} >
  <option value=" ">Portfolio</option>
  {
    Portfoliodata.map((getport,index)=>(
            <option key={index} value={getport._id}>{getport.PorfolioName}</option>
    ))
  }
  </select>
 </div>

 <div>
 <select >
  <option value=" ">Portfolio</option>
    {
      SubApplicationdata.map((getsub,index)=>(
<option key={index} value={getsub._id}>{getsub.SubApplicationName}</option>
      ))
    }
  </select>
 </div>

 <div>
 <select >
  <option value=" ">Portfolio</option>
    <option value=" "> rtr</option>
    <option value="">stp</option>
  </select>
 </div>
  </form>
  
</div>

</div>

    </>
  )
}

export default Dataf