import React from "react";
// import handleEditClickdataflow from "./DataFlow";
import "./ReadOnlyRowdataflow.css";

const ReadOnlyRowdataflow=({getport,index,handleEditClick,handleDeleteClick})=>{
return (
    <>

   <div className="left-side-data">
<tr>
    <td  className="flow-target1"key={index}>
   {getport.Application2}  
    </td>
    <td>
        <button type="button" className="Edit" onClick={(event)=>handleEditClick(event,getport)}>Edit</button>
    <button type="button"  className="Edit"onClick={()=>handleDeleteClick(getport._id)}>Delete</button>
    </td>
</tr>
</div>
 
  
   
    
    </>
)
}
export default ReadOnlyRowdataflow;