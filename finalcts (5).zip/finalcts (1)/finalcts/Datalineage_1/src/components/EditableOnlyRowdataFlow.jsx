import React from 'react'

const EditableOnlyRowdataFlow = ({editFormData,handleEditFormChange,handleCancelClick}) => {
  return (
    <div>
   <tr>
    <td>
    <input className="flow-target1" name='Application2'value={editFormData.Application2} onChange={handleEditFormChange}></input> 
    </td>
    <td>
        <button type='submit'>Save</button>
        <button type='button' onClick={handleCancelClick}> cancel</button>
    </td>
   </tr>
    </div>
  )
}

export default EditableOnlyRowdataFlow
