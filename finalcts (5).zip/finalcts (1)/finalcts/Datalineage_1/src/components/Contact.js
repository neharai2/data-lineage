import React from 'react'
import Navbar from './horizontalNav/Navbar';
import "./Contact.css"
const Contact = () => {
  return (
    <>

    
    <div className='contact-container'> 
    <div>
    <Navbar/>
    </div>
   <div className='contact-title'>
   <h1 className="contact">Contact US</h1>
   <br></br>
   <div className='email-config'>
   <div >
   <h4>Surya Ponnusammy</h4>
   <span>Email ID:Surya.Prakash3@cognizant.com</span>
   </div>
   
   
   <div>
   <h4>Pavithra Balasubramaniam</h4>
   <span>Email ID:Balasubramaniam3.Pavithra@cognizant.com</span>
   </div>
   </div>
   </div>
    </div>
 


    </>  )
}

export default Contact;