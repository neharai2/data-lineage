import React,{useState,useEffect, Fragment} from "react";
import Dataf from "./horizontalNav/dataf";
import "./dataStyle.css";
import{VscArrowRight}from 'react-icons/vsc'
import{VscArrowLeft}from 'react-icons/vsc'
import ReadOnlyRowdataflow from "./ReadOnlyRowdataflow";
import EditableOnlyRowdataFlow from "./EditableOnlyRowdataFlow";
                                        
const DataFlow = () => {
  const[Flowchartdata,SetFlowchartdata]=useState([]); 
  const[addFormData,setAddFormData]=useState({
    Application1:" ",
    Application2:" "
  }) 
const[editedContactid,setEditContactId]=useState(null);

const [editFormData,setEditFormData]=useState({
  Application2:" ",
  Application1:" ",
})
  useEffect(()=>{
    const getflowchartall=async()=>{ 
    const resflowchart=  await fetch(`http://localhost:4200/data/getflowchart/633c071f77b11b76a54741af`);
    const resflowchartdata=await resflowchart.json();
    SetFlowchartdata( await resflowchartdata)
  }
  getflowchartall();
  },[])
 
 

  const handleEditClick=(event,getport)=>{
event.preventDefault();
setEditContactId(getport._id);

const formValues={
  Application2:getport.Application2,
  Application1:getport.Application1
}
setEditFormData(formValues);
  }

const handleEditFormChange=(event)=>{
event.preventDefault();
const fieldName=event.target.getAttribute("name");
const fieldValue=event.target.value;
const newFormData={...editFormData};
newFormData[fieldName]=fieldValue;
setEditFormData(newFormData);
}

const handleEditFormSubmit=(event)=>{
event.preventDefault();
const editedContact={
  Application2:editFormData.Application2,
  Application1:editFormData.Application1
}
const{Application1,Application2}=addFormData;
fetch(`http://localhost:4200/data/getflowchart/item/edit/:id`, {
  method: 'patch',
  headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
  },
  body: JSON.stringify({ 
  Application1,
  Application2 
  })
})
.then(()=>{
  alert('Data Updated !!!');
})

const newContacts=[...Flowchartdata];
const index = Flowchartdata.findIndex((getport) => getport._id === editedContactid);
newContacts[index]=editedContact;
SetFlowchartdata(newContacts);
console.log(Flowchartdata);
setEditContactId(null);
}

const handleCancelClick=()=>{
  setEditContactId(null);
}

const handleDeleteClick=(contactId)=>{
const newContact=[...Flowchartdata];
const index=Flowchartdata.index((getport)=>getport._id===contactId);
newContact.splice(index,1);
SetFlowchartdata(newContact);
}


  return (
    <div className="flow-container">
   {/*dropdown*/}
      <div>
      <Dataf/>
      </div>
     {/* left hand side target data */}
     <form onSubmit={handleEditFormSubmit}>
      <div className="flow-dataget">   
      <table>
        <tbody> 
  {
    Flowchartdata.filter(h=>!h.Application1).map((getport,index)=>(  
 
          <Fragment>
            {editedContactid===getport._id?<EditableOnlyRowdataFlow
            editFormData={editFormData} handleEditFormChange={handleEditFormChange}
            handleCancelClick={handleCancelClick}
            />:  
            <ReadOnlyRowdataflow getport={getport} handleEditClick={handleEditClick} 
            handleDeleteClick={handleDeleteClick}/>}   
          </Fragment>     
       
    ))
  }
   </tbody>
      </table>
    </div>
      </form>

    {/* arrow mark  */}
    <div className="flow-dataget">     
  {
    Flowchartdata.filter(h=>!h.Application1 && h.Direction === "outbound").map((getport,index)=>(
    <div className="flow-target-arrow" key={index} value={getport._id}><VscArrowRight/> </div>
                     
    ))
  }
    </div>
    {/* left hand side target data arrow mark */}
 <div className="flow-dataget">     
  {
    Flowchartdata.filter(h=>!h.Application1).map((getport,index)=>(
      //console.log(getport)
            <h6 className="flow-target-arrow-data"key={index} >{getport.Notes}</h6>
    ))
  }
    </div>
        {/* Laia static */}
        <div className="flow-dataget-2">
          <h3 className="flow-target3">Laia</h3>
        </div>
{/* arrow mark data */}
        <div className="flow-dataget">     
  {
    Flowchartdata.filter(h=>!h.Application2).map((getport,index)=>(
      //console.log(getport)
            <h6 className="flow-target-arrow-data1"key={index} >{getport.Notes}</h6>
    ))
  }
    </div>
          {/* right hand side ARROW DATA*/}
          <div className="flow-dataget">     
  {
    Flowchartdata.filter(h=>!h.Application2 && h.Direction.toLowerCase() === "outbound").map((getport,index)=>(
            <div className="flow-target-arrow-Left" key={index} ><VscArrowLeft/></div>    
    ))
  }
        </div>
        {/* right hand side target data */}
        <div className="flow-dataget">     
  {
    Flowchartdata.filter(h=>!h.Application2).map((getport,index)=>(
            <button className="flow-target2" key={index} >{getport.Application1}</button>    
    ))
  }
        </div>
      </div>
  );
};
export default DataFlow;