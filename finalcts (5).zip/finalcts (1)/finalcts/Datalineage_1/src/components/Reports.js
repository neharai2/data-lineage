import React from 'react'
import Navbar from './horizontalNav/Navbar';
import "./Contact.css"

const Reports = () => {
  return (
    <>   
<div className='contact-container'> 
<div>
<Navbar/>
</div>
<div className='contact-title'>
<h1 className="contact">Report Us</h1>
</div>
</div>
    </>
  )
}

export default Reports;